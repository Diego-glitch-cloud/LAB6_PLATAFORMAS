package com.example.clase27ag

import com.squareup.moshi.Json

data class PexelsResponse(
    val page: Int,
    @Json(name = "per_page") val perPage: Int,
    val photos: List<PexelsPhoto>,
    @Json(name = "next_page") val nextPage: String?
)